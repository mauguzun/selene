<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');



/**
* 
*  top menu 
*/
$lang['admin_left_menu'] =
 	[
 		// link  = ['class'=>'url']
 		'Slideshow homepage'=>[
 			'icon-home4'=>'admin/index'
 		],
 		'News'=>['far fa-newspaper'=>'#'],
 		'Our recruitment policy'=>['fas fa-file-alt'=>'#'],
 		'Confidentiality declaration'=>['fas fa-file-alt'=>'#'],
 		'Layouts'=>[
 			'icon-copy'=>
 				['Dashboard'=>'#'],
 				['Manage your offers'=>'#'],
 				['Cv'=>'#'],
 				['Field of activity'=>'#'],
 				['Domains and functions'=>'#'],
 			],
 			
 		'Text mails'=>['fas fa-envelope'=>'#'],
 		
 		'Administrator Profile'=>['fas fa-unlock-alt'=>'#'],
 		'Koнтент'=>['fas fa-pencil-alt'=>''],
 	     
 	];
 	
 $lang['Slideshow homepage']='';
 	

 	
	
